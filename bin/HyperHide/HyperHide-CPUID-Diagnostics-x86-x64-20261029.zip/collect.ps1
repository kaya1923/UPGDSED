[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('drivers-off', 'v5-airhv-only', 'v6-airhv-only')]
    [string]$State,

    [string]$OutputDirectory = ''
)

$ErrorActionPreference = 'Stop'
if (-not $OutputDirectory) {
    $OutputDirectory = Join-Path $PSScriptRoot 'captures'
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$captureDirectory = Join-Path $OutputDirectory "$stamp-$State"
New-Item -ItemType Directory -Path $captureDirectory -Force | Out-Null

@(
    "state=$State"
    "captured=$(Get-Date -Format o)"
    "computer=$env:COMPUTERNAME"
    "windows_build=$([Environment]::OSVersion.Version.Build)"
) | Set-Content -LiteralPath (Join-Path $captureDirectory 'context.txt') -Encoding ascii

foreach ($service in @('airhv', 'HyperHideDrv')) {
    & sc.exe query $service 2>&1 |
        Out-File -LiteralPath (Join-Path $captureDirectory "service-$service.txt") -Encoding ascii
}

foreach ($architecture in @('x86', 'x64')) {
    $program = Join-Path $PSScriptRoot "cpuid_diagnostic-$architecture.exe"
    if (-not (Test-Path -LiteralPath $program -PathType Leaf)) {
        throw "Diagnostic executable missing: $program"
    }
    & $program 2>&1 |
        Tee-Object -FilePath (Join-Path $captureDirectory "cpuid-$architecture.txt")
    if ($LASTEXITCODE -ne 0) {
        throw "cpuid_diagnostic-$architecture.exe failed with exit code $LASTEXITCODE"
    }
}

Get-FileHash -Algorithm SHA256 -LiteralPath @(
    (Join-Path $captureDirectory 'cpuid-x86.txt'),
    (Join-Path $captureDirectory 'cpuid-x64.txt')
) | Format-Table -AutoSize |
    Out-File -LiteralPath (Join-Path $captureDirectory 'capture-hashes.txt') -Encoding ascii

Write-Host "Capture complete: $captureDirectory" -ForegroundColor Green
