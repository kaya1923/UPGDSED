airhv CPUID diagnostic bundle 1.0.0-20261029

PURPOSE
This package records CPUID input leaf/subleaf, EAX/EBX/ECX/EDX and timing
distributions. It does not install, start, stop or patch a driver. It does not
claim that any particular CPUID value proves a VM.

The same x86 and x64 binaries must be used for every state. Do not rebuild
between captures.

HP-BENCH COMMANDS (PowerShell)

1. Both drivers stopped; verify with sc.exe query before capture:
   powershell -ExecutionPolicy Bypass -File .\collect.ps1 -State drivers-off

2. Start only the unchanged known-good v5 airhv with the v5 bundle:
   powershell -ExecutionPolicy Bypass -File <v5-path>\start.ps1 -AirhvOnly
   powershell -ExecutionPolicy Bypass -File .\collect.ps1 -State v5-airhv-only
   powershell -ExecutionPolicy Bypass -File <v5-path>\stop.ps1

3. Only if a v6 comparison is still wanted, start v6 airhv alone and capture:
   powershell -ExecutionPolicy Bypass -File <v6-path>\start.ps1 -AirhvOnly
   powershell -ExecutionPolicy Bypass -File .\collect.ps1 -State v6-airhv-only
   powershell -ExecutionPolicy Bypass -File <v6-path>\stop.ps1

Copy the complete captures directory back to the repository. Compare exact
register values first. Treat median/p95/p99/mean/stdev only as distributions;
isolated timing spikes are not a diagnosis.

RECORDED LEAVES
- 0, 1 and 7/0, including reported maxima and the first invalid boundary
- 0x40000000, 0x40000001, 0x40000010 and 0x4FFFFFFF
- 0x80000000, reported maximum extended leaf, first invalid extended leaf,
  and 0x8FFFFFFF
- reported maximum and first invalid leaf-7 subleaf

OPEN QUESTION
No airhv CPUID fix is included. A minimal VM-exit change should only be selected
after the three state captures show which values actually differ. Other leaks
(VM-exit timing, descriptor/interrupt behavior, devices, firmware and system
configuration) can remain even if the hypervisor-present bit or 0x40000000
leaves are hidden.

BUILD PC VALIDATION
- x86 and x64 binaries built successfully with MSVC 14.51.36231 and SDK 10.0.26100.0
- PE machine types verified offline
- programs intentionally not executed on the build PC
